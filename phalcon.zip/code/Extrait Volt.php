{% block produit %}
	{% for produit in produits %}
	    * Nom : {{ produit.nom|e }}
	    {% if produit.status == 'actif' %}
	       produit : {{ produit.prix + produit.taxes/100 }}
	    {% endif %}
	{% endfor %}
{% endblock %}
