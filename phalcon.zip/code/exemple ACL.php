<?php

use Phalcon\Acl\Role;
use Phalcon\Acl\Component;

$oAcl = new Phalcon\Acl\Adapter\Memory();
$oAcl->setDefaultAction(Phalcon\Acl\Enum::DENY);


$aRoles = [ 
   'vendeurs' => new Role( 
       'vendeurs', 
       'Accès uniquement à la section de vente de produits.' 
   ), 
   'clients'  => new Role( 
       'clients', 
       'Accès uniquement à la section d\'achat de produits.' 
   ) 
]; 
 
foreach ($aRoles as $oRole) { 
   $oAcl->addRole($oRole); 
}


$aActionParRole = [ 
   'vendeurs' => [ 
       'vendeurs' => [ 'profil' ], 
       'produits' => [ 'nouveau', 'édition' ] 
   ], 
   'clients'  => [ 
       'clients'  => [ 'profil' ], 
       'produits' => [ 'acheter' ] 
   ], 
   '*' => [ 
       'index'   => [ 'index', 'connexion', 'déconnexion' ], 
       'erreurs' => [ '*' ] 
   ] 
]; 
 
foreach ($aActionParRole as $sRole => $aRole) { 
   foreach ($aRole as $sControleur => $aActions) { 
       $oComponentControleur = new Component($sControleur); 
       foreach($aActions as $sAction){ 
           $oAcl->addComponent($oComponentControleur, $sAction); 
           $oAcl->allow($sRole, $sControleur, $sAction); 
       } 
   } 
}

var_dump($oAcl->isAllowed('clients', 'produits', 'acheter'));
var_dump($oAcl->isAllowed('clients', 'produits', 'nouveau'));