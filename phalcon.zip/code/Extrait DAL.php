$this->db->fetchAll(' 
   SELECT id, prenom, nom, email  
   FROM utilisateurs  
   WHERE prenom = :prenom',  
   Db::FETCH_ASSOC,  
   [ 
       'prenom' => 'Louise', 
       'id'     => 2 
    ] 
);
