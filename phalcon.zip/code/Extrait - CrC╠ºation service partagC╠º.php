//Création du service
$di->setShared('config', function () { 
   return include APP_PATH . "/config/config.php"; 
}); 

//Récupération du service
$oConfig = $this->di->get('config');