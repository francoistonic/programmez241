$oConstructeur = $this->modelsManager
		->createBuilder()
		->from(Utilisateurs::class);

$oPaginateur = new QueryBuilder(
    [
        'builder' => $oConstructeur,
        'limit'   => 10,
        'page'    => $nPageCourante,
    ]
);

$oPagine = $oPaginateur->paginate();
