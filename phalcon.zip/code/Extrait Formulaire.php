class Utilisateur extends Form
{
    public function initialize()
    {
        $oEmail = new Email('email', [
            'placeholder' => 'Saisir un e-mail',
            'class'       => 'form-control',
        ]);
        $oEmail->setLabel('E-mail');
        $this->add($oEmail);

        $oMotDePasse = new Password('mot_de_passe', [
            'placeholder' => 'Saisir un mot de passe',
            'class'       => 'form-control',
        ]);
        $oMotDePasse->setLabel('Mot de passe');
        $this->add($oMotDePasse);
    }
}

// En volt
{{ form.label("email") }}

//Généré
<label for="email">E-mail</label>

{{ form.render('email') }}

//Généré
<input type="email" id="email" name="email" class="form-control" placeholder="Saisir un e-mail">