$oCache = $this->di->get('cache');
$sCleCache = 'loto.resultats';

$aResultats  = $oCache->get($sCleCache);

if ($aResultats  === null) {

	$aResultats  = Loto::getResultats();
	
	$oCache->set($sCleCache, $aResultats , 86400);
}
