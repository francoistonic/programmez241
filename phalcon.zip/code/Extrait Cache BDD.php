$oRequete = $this->modelsManager->createQuery('SELECT *  
               FROM NovaMooc\Models\Utilisateurs 
                   WHERE prenom LIKE :prenom:'); 
$oRequete->cache( 
   [ 
       'key'      => 'utilisateurs_phql', 
       'lifetime' => 14400, 
   ] 
); 
