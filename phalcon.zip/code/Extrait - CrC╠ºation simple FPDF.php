// Création du service
$di->set('fpdf', function () { 
       $oPdf = new Fpdf(); 
 
       $oPdf->AddPage(); 
       $oPdf->Image('logo_entete.png',8,5,25); 
 
       return $oPdf; 
   } 
);

// Récupération du service
$oPDF = $this->di->get('fpdf');