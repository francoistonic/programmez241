<?php

$sPHQL = 'SELECT * FROM NovaMooc\Models\Utilisateurs  
           WHERE prenom like :prenom:'; 
 
$aResultat = $this->modelsManager->executeQuery( 
   $sPHQL,  
   [  
       'prenom' => '%a%'  
   ] 
);

?>