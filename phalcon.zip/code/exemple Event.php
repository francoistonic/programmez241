use Phalcon\Mvc\Dispatcher;
use Phalcon\Events\Manager;

$container->set(
    'dispatcher',
    function () {

        $oGestionnaireEvenement = new Manager();

        $oGestionnaireEvenement->attach(
            'dispatch:beforeExecuteRoute',
            new SecuritePlugin
        );

        $oGestionnaireEvenement->attach(
            'dispatch:beforeException',
            new ErreurPlugin
        );

        $oDispatcheur = new Dispatcher();

        $oDispatcheur
            ->setEventsManager($oGestionnaireEvenement);

        return $oDispatcheur;
    }
);
