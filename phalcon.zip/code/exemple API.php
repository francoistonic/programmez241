<?php
use Phalcon\Mvc\Micro;

$app = new Micro();

// Returning data in JSON
$app->get(
    '/',
    function () {
        return $this->response->setJsonContent(
                [
                    'status' => 'important',
                ]
            )
        ;
    }
);

$app->notFound(function () use($app) {
    $app->response->setStatusCode(404, "Not Found")->sendHeaders();
});

$app->handle($_GET['_url'] ?? '/');