<?php

namespace NovaMooc\Models;

use Phalcon\Mvc\Model;

use Phalcon\Validation;
use Phalcon\Validation\Validator\Email as EmailValidator;

class Utilisateur extends Model
{
    public $email;

    public $password;

    public function initialize()
    {
        $this->hasMany('id', Cours::class, 'utilisateur_id', [ 'alias' => 'cours' ]);
    }

    public function validation()
    {
        $validator = new Validation();

        $validator->add('email',new EmailValidator(
                [
                    'model'   => $this,
                    'message' => 'Veuillez entrer une adresse mail correcte',
                ]
            )
        );

        return $this->validate($validator);
    }
}
?>       